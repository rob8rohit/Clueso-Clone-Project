
# Clueso.io Clone (Assignment Project)

## Tech Stack
- Backend: Spring Boot (Java)
- Frontend: HTML, CSS, JavaScript

## How to Run Backend
1. Open backend folder in Eclipse
2. Run `CluesoCloneApplication.java`
3. Server runs on http://localhost:8080

## How to Run Frontend
1. Open frontend/index.html in browser
2. Make sure backend is running

## Features
- Add video metadata
- View video list
- REST API integration

This project is assignment-ready.
