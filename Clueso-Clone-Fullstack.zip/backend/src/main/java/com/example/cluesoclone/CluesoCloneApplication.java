
package com.example.cluesoclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CluesoCloneApplication {
    public static void main(String[] args) {
        SpringApplication.run(CluesoCloneApplication.class, args);
    }
}
