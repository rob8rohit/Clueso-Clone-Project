
package com.example.cluesoclone.controller;

import com.example.cluesoclone.model.Video;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/videos")
@CrossOrigin
public class VideoController {

    private List<Video> videos = new ArrayList<>();

    @PostMapping
    public Video addVideo(@RequestBody Video video) {
        video.setId((long) (videos.size() + 1));
        videos.add(video);
        return video;
    }

    @GetMapping
    public List<Video> getVideos() {
        return videos;
    }
}
