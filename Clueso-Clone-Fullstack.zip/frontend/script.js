
function addVideo() {
    const title = document.getElementById('title').value;
    const desc = document.getElementById('desc').value;

    fetch('http://localhost:8080/api/videos', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({title, description: desc})
    }).then(loadVideos);
}

function loadVideos() {
    fetch('http://localhost:8080/api/videos')
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById('list');
            list.innerHTML = '';
            data.forEach(v => {
                const li = document.createElement('li');
                li.innerText = v.title + ' - ' + v.description;
                list.appendChild(li);
            });
        });
}

loadVideos();
